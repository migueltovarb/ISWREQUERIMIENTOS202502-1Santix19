        # sistema_talleres

        Proyecto Django de ejemplo para gestionar talleres y seminarios.

        ## Instrucciones rápidas

        1. Crear y activar un entorno virtual (recomendado):

```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
venv\Scripts\activate     # Windows
```

2. Instalar dependencias:
```bash
pip install -r requirements.txt
```

3. Migrar la base de datos y crear superusuario:
```bash
python manage.py migrate
python manage.py createsuperuser
```

4. Ejecutar el servidor:
```bash
python manage.py runserver
```

5. Acceder a http://127.0.0.1:8000/eventos/talleres/ o al admin en /admin/
