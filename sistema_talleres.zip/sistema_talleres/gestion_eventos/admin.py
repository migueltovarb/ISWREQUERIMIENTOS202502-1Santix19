from django.contrib import admin
from .models import Ponente, Taller, Seminario, Inscripcion

admin.site.register(Ponente)

@admin.register(Taller)
class TallerAdmin(admin.ModelAdmin):
    list_display = ('titulo', 'fecha_inicio', 'ponente', 'cupo_maximo', 'cupos_disponibles')
    search_fields = ('titulo', 'ponente__nombre')
    list_filter = ('fecha_inicio',)

@admin.register(Seminario)
class SeminarioAdmin(admin.ModelAdmin):
    list_display = ('titulo', 'fecha_inicio', 'ponente', 'cupo_maximo', 'cupos_disponibles')
    search_fields = ('titulo', 'ponente__nombre')
    list_filter = ('fecha_inicio',)

@admin.register(Inscripcion)
class InscripcionAdmin(admin.ModelAdmin):
    list_display = ('participante_nombre', 'participante_email', 'get_evento_titulo', 'fecha_inscripcion')
    search_fields = ('participante_nombre', 'participante_email')
    list_filter = ('fecha_inscripcion',)

    def get_evento_titulo(self, obj):
        return obj.evento_taller.titulo if obj.evento_taller else obj.evento_seminario.titulo
    get_evento_titulo.short_description = 'Evento'
