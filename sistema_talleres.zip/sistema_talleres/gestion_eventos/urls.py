from django.urls import path
from . import views

urlpatterns = [
    path('talleres/', views.TallerListView.as_view(), name='lista_talleres'),
    path('seminarios/', views.SeminarioListView.as_view(), name='lista_seminarios'),
    path('<str:tipo>/<int:evento_id>/', views.detalle_evento, name='detalle_evento'),
]
