from django.shortcuts import render, get_object_or_404, redirect
from django.views.generic import ListView
from django.contrib import messages
from .models import Taller, Seminario
from .forms import InscripcionForm

class TallerListView(ListView):
    model = Taller
    template_name = 'gestion_eventos/lista_eventos.html'
    context_object_name = 'talleres'

class SeminarioListView(ListView):
    model = Seminario
    template_name = 'gestion_eventos/lista_eventos.html'
    context_object_name = 'seminarios'

def detalle_evento(request, evento_id, tipo):
    if tipo == 'taller':
        EventoModel = Taller
    elif tipo == 'seminario':
        EventoModel = Seminario
    else:
        messages.error(request, "Tipo de evento no válido.")
        return redirect('lista_talleres')

    evento = get_object_or_404(EventoModel, pk=evento_id)
    form = InscripcionForm()
    inscripcion_exitosa = False

    if request.method == 'POST':
        form = InscripcionForm(request.POST)
        if form.is_valid():
            if evento.cupos_disponibles() > 0:
                inscripcion = form.save(commit=False)

                if tipo == 'taller':
                    inscripcion.evento_taller = evento
                else:
                    inscripcion.evento_seminario = evento

                inscripcion.save()
                messages.success(request, f"¡Inscripción exitosa al evento '{evento.titulo}'!")
                form = InscripcionForm()
                inscripcion_exitosa = True
            else:
                messages.error(request, "Lo sentimos, el cupo máximo ha sido alcanzado para este evento.")
        else:
            messages.error(request, "Por favor, corrige los errores en el formulario.")

    context = {
        'evento': evento,
        'form': form,
        'tipo': tipo,
        'inscripcion_exitosa': inscripcion_exitosa
    }
    return render(request, 'gestion_eventos/detalle_evento.html', context)
