from django import forms
from .models import Inscripcion

class InscripcionForm(forms.ModelForm):
    class Meta:
        model = Inscripcion
        fields = ['participante_nombre', 'participante_email']
        widgets = {
            'participante_nombre': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Tu Nombre Completo'}),
            'participante_email': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'ejemplo@correo.com'}),
        }
