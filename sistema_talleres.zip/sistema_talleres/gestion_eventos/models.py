from django.db import models

class Ponente(models.Model):
    nombre = models.CharField(max_length=100)
    apellido = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    bio = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"{self.nombre} {self.apellido}"

class Evento(models.Model):
    TIPO_CHOICES = (
        ('T', 'Taller'),
        ('S', 'Seminario'),
    )
    titulo = models.CharField(max_length=200)
    descripcion = models.TextField()
    fecha_inicio = models.DateTimeField()
    fecha_fin = models.DateTimeField()
    cupo_maximo = models.IntegerField(default=20)
    ponente = models.ForeignKey(Ponente, on_delete=models.SET_NULL, null=True)
    tipo = models.CharField(max_length=1, choices=TIPO_CHOICES, default='T')

    class Meta:
        abstract = True
        ordering = ['fecha_inicio']

    def cupos_disponibles(self):
        inscritos = self.inscripcion_set.count()
        return self.cupo_maximo - inscritos

    def __str__(self):
        return self.titulo

class Taller(Evento):
    ubicacion = models.CharField(max_length=150)

class Seminario(Evento):
    link_virtual = models.URLField(blank=True, null=True)

class Inscripcion(models.Model):
    participante_nombre = models.CharField(max_length=100)
    participante_email = models.EmailField()
    evento_taller = models.ForeignKey(Taller, on_delete=models.CASCADE, null=True, blank=True)
    evento_seminario = models.ForeignKey(Seminario, on_delete=models.CASCADE, null=True, blank=True)
    fecha_inscripcion = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name_plural = "Inscripciones"
        constraints = [
            models.CheckConstraint(
                check=models.Q(evento_taller__isnull=False, evento_seminario__isnull=True) |
                      models.Q(evento_taller__isnull=True, evento_seminario__isnull=False),
                name='evento_solo_uno'
            )
        ]

    def __str__(self):
        evento = self.evento_taller or self.evento_seminario
        return f"Inscripción de {self.participante_email} en {evento.titulo if evento else 'N/A'}"
